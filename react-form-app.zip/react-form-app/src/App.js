import { Routes, Route } from 'react-router-dom';
import RegistrationForm from './RegistrationForm';
import SubmittedPage from './SubmittedPage';

function App() {
  return (
    <Routes>
      <Route path="/" element={<RegistrationForm />} />
      <Route path="/submitted" element={<SubmittedPage />} />
    </Routes>
  );
}

export default App;
