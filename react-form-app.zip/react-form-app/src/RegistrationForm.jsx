import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const countries = {
  India: ["Delhi", "Mumbai", "Bangalore"],
  USA: ["New York", "Los Angeles", "Chicago"],
  Canada: ["Toronto", "Vancouver", "Montreal"],
};

export default function RegistrationForm() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    username: "",
    email: "",
    password: "",
    showPassword: false,
    phoneCode: "",
    phoneNumber: "",
    country: "",
    city: "",
    pan: "",
    aadhar: "",
  });

  const [errors, setErrors] = useState({});
  const [isValid, setIsValid] = useState(false);

  // Validate fields and update errors
  const validate = () => {
    const newErrors = {};

    if (!formData.firstName.trim()) newErrors.firstName = "First name is required";
    if (!formData.lastName.trim()) newErrors.lastName = "Last name is required";
    if (!formData.username.trim()) newErrors.username = "Username is required";

    if (!formData.email.trim()) newErrors.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email))
      newErrors.email = "Invalid email format";

    if (!formData.password) newErrors.password = "Password is required";

    if (!formData.phoneCode.trim() || !formData.phoneNumber.trim())
      newErrors.phone = "Phone country code and number are required";

    if (!formData.country) newErrors.country = "Country is required";
    if (!formData.city) newErrors.city = "City is required";

    if (!formData.pan.trim()) newErrors.pan = "PAN is required";
    else if (!/^([A-Z]{5}[0-9]{4}[A-Z]{1})$/.test(formData.pan))
      newErrors.pan = "PAN format invalid (e.g. ABCDE1234F)";

    if (!formData.aadhar.trim()) newErrors.aadhar = "Aadhar is required";
    else if (!/^\d{12}$/.test(formData.aadhar))
      newErrors.aadhar = "Aadhar must be 12 digits";

    setErrors(newErrors);

    return Object.keys(newErrors).length === 0;
  };

  // Update validity for disabling submit button (simple check)
  useEffect(() => {
    const requiredFilled = [
      "firstName",
      "lastName",
      "username",
      "email",
      "password",
      "phoneCode",
      "phoneNumber",
      "country",
      "city",
      "pan",
      "aadhar",
    ].every((field) => formData[field].trim() !== "");

    setIsValid(requiredFilled);
  }, [formData]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
      // Reset city if country changes
      ...(name === "country" && { city: "" }),
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validate()) {
      navigate("/submitted", { state: formData });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-xl mx-auto p-4 space-y-4">
      <input
        name="firstName"
        placeholder="First Name"
        value={formData.firstName}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.firstName && <p className="text-red-500 text-sm">{errors.firstName}</p>}

      <input
        name="lastName"
        placeholder="Last Name"
        value={formData.lastName}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.lastName && <p className="text-red-500 text-sm">{errors.lastName}</p>}

      <input
        name="username"
        placeholder="Username"
        value={formData.username}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.username && <p className="text-red-500 text-sm">{errors.username}</p>}

      <input
        name="email"
        placeholder="Email"
        type="email"
        value={formData.email}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}

      <div>
        <input
          name="password"
          placeholder="Password"
          type={formData.showPassword ? "text" : "password"}
          value={formData.password}
          onChange={handleChange}
          className="w-full p-2 border"
        />
        <label className="inline-block mt-1 text-sm">
          <input
            type="checkbox"
            name="showPassword"
            checked={formData.showPassword}
            onChange={handleChange}
          />{" "}
          Show Password
        </label>
        {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
      </div>

      <div className="flex gap-2">
        <input
          name="phoneCode"
          placeholder="Country Code"
          value={formData.phoneCode}
          onChange={handleChange}
          className="w-1/3 p-2 border"
        />
        <input
          name="phoneNumber"
          placeholder="Phone Number"
          value={formData.phoneNumber}
          onChange={handleChange}
          className="w-2/3 p-2 border"
        />
      </div>
      {errors.phone && <p className="text-red-500 text-sm">{errors.phone}</p>}

      <select
        name="country"
        value={formData.country}
        onChange={handleChange}
        className="w-full p-2 border"
      >
        <option value="">Select Country</option>
        {Object.keys(countries).map((country) => (
          <option key={country} value={country}>
            {country}
          </option>
        ))}
      </select>
      {errors.country && <p className="text-red-500 text-sm">{errors.country}</p>}

      <select
        name="city"
        value={formData.city}
        onChange={handleChange}
        className="w-full p-2 border"
        disabled={!formData.country}
      >
        <option value="">Select City</option>
        {(countries[formData.country] || []).map((city) => (
          <option key={city} value={city}>
            {city}
          </option>
        ))}
      </select>
      {errors.city && <p className="text-red-500 text-sm">{errors.city}</p>}

      <input
        name="pan"
        placeholder="PAN Number"
        value={formData.pan}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.pan && <p className="text-red-500 text-sm">{errors.pan}</p>}

      <input
        name="aadhar"
        placeholder="Aadhar Number"
        value={formData.aadhar}
        onChange={handleChange}
        className="w-full p-2 border"
      />
      {errors.aadhar && <p className="text-red-500 text-sm">{errors.aadhar}</p>}

      <button
        type="submit"
        disabled={!isValid}
        className="w-full bg-blue-500 text-white p-2 disabled:bg-gray-400"
      >
        Submit
      </button>
    </form>
  );
}
