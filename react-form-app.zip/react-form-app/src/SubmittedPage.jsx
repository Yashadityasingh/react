import { useLocation } from "react-router-dom";

export default function SubmittedPage() {
  const { state } = useLocation();

  if (!state) return <p>No form data found.</p>;

  return (
    <div className="max-w-xl mx-auto p-4">
      <h2 className="text-xl font-bold mb-4">Submitted Info</h2>
      <ul className="space-y-2">
        {Object.entries(state).map(([key, value]) => (
          <li key={key}>
            <strong>{key}:</strong> {String(value)}
          </li>
        ))}
      </ul>
    </div>
  );
}
